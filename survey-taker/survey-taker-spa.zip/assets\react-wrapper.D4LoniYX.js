const t=window.React;export{t as R};
